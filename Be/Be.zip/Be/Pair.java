import java.util.*;
import java.io.*;


public class Pair {
	Pair() {

	}

	public Pair(int index, Node szukany) {
		this.index = index;
		this.szukany = szukany;
	}

	public int index;
	public Node szukany;
}

