public class Drzefko {


	Drzefko() {
		root = null;
	}	

	public int len;
	public int h;
	public Node root;
}